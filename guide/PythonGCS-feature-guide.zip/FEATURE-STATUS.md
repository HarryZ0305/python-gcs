# Feature status and remaining work

This describes the committed source, not operational flight readiness.
**Implemented** means a code path exists. **Experimental** means implemented with
remaining validation. **Work in progress** includes planned work that is not
implemented yet; it does not imply availability or a committed delivery date.

## Accurate project description

> Customized drone GCS with OpenStreetMap, improved mission planning, and an experimental telemetry-driven 3D attitude viewer; PX4/Gazebo integration and real-aircraft validation are work in progress.

“Live 3D modeling” would overstate the current implementation: the viewer rotates
a drone model using roll, pitch, and yaw. It does not reconstruct terrain or
display a Gazebo world. “Equipped with Gazebo” would overstate packaging: the GCS
targets a separately installed PX4/Gazebo environment.

## Implementation evidence and next steps

| Capability | Evidence | Status and remaining work |
| --- | --- | --- |
| Customized desktop GCS | [GUI](../gcs/ui/gui.py), [theme](../gcs/ui/theme.py) | **Implemented:** six workspaces, optional video and detached diagnostics. |
| OpenStreetMap | [Map](../gcs/ui/map_view.py), [tile server](../gcs/ui/tile_server.py), [tests](../tests/test_tile_server.py) | **Implemented desktop paths:** Leaflet, OSM tiles, caching and MBTiles. Normal-graphics/offline-package visual acceptance remains **work in progress**. The browser currently uses a coordinate grid; geographic browser maps are **planned work in progress**. |
| Autonomous mission planning | [Editor](../gcs/ui/plan_view.py), [survey generator](../gcs/ui/survey_dialog.py), [tests](../tests/test_mission.py) | **Local tools implemented:** editing, survey generation and a limited `.plan` subset. Complete PX4/Gazebo mission execution and real-aircraft acceptance are **work in progress**. This does not establish obstacle avoidance or general autonomous navigation. |
| Actual PX4 connection | [Connection](../gcs/connection.py), [telemetry](../gcs/telemetry.py), [protocol tests](../tests/test_operator_safety.py) | **Transport/telemetry code implemented; hardware validation work in progress.** Tests use encoded MAVLink packets and test doubles; they do not prove a physical aircraft was connected or flown. Validate connection lifecycle, identity, sensor freshness, commands and failsafes on the intended aircraft. |
| Gazebo / PX4 SITL | [Development setup](../README.md#run-the-desktop-app), [acceptance checklist](desktop-upgrade.md#remaining-flight-acceptance) | **Integration work in progress.** The desktop targets MAVLink from a separately configured simulator. Complete, repeatable end-to-end acceptance remains unfinished. An initial SITL smoke test is not full acceptance. Gazebo is not bundled or launched by the GCS. |
| 3D aircraft attitude | [Three.js viewer](../gcs/ui/attitude_view.py), [telemetry updates](../gcs/ui/flight_instruments.py) | **Experimental implementation; validation work in progress.** The model receives roll/pitch/yaw. WebGL was unavailable in the capture environment. Rendering and orientation need validation with simulator telemetry before claiming validated live operation. |
| Browser aircraft connection / parameter writes | [Browser demo](../web_gcs.html), [local model](../assets/demo-model.js) | **Work in progress — planned, not implemented yet.** Current data is generated locally and parameters are examples. A real MAVLink transport/backend and connection lifecycle are required. |
| Full flight-log replay | [Analyze view](../gcs/ui/analyze_view.py) | **Historical CSV review implemented; full replay work in progress — planned, not implemented yet.** |
| Broader missions and advanced autonomy | [Current scope](desktop-upgrade.md) | **Work in progress — planned extensions:** terrain following, geofence editing, calibration wizards and full QGC ComplexItem support. Unsupported imports remain rejected today. |
| 3D terrain reconstruction | No reconstruction pipeline in committed source | **Work in progress — planned, not implemented yet.** The attitude viewer is not terrain reconstruction or a digital twin. |

Screenshots show interface layouts and illustrative data, not evidence of a live
PX4 flight. Future-work labels do not change current command guards or import limits.
