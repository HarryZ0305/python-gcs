**Work in progress:** PX4/Gazebo integration, real-aircraft validation and 3D graphics acceptance. Browser aircraft connections and terrain reconstruction are planned, not implemented yet. See FEATURE-STATUS.md.

# PythonGCS — illustrated feature guide

17 annotated views: all six main workspaces plus the principal dialogs and viewing modes.

Bold labels and numbered markers identify features. Sample mission, parameter and plot data are illustrative. No aircraft is connected. Standard operating-system file pickers and transient error messages are not separate product screens.

## 01 / Fly — the main flight screen

**Open: Fly**

- **Connection** — Open connection profiles and connect to a vehicle or simulator.
- **Aircraft status** — Armed state, flight mode, GNSS and battery are always visible.
- **Attitude display** — Artificial horizon, heading, speed and altitude tapes; 2D / 3D selector.
- **Key telemetry** — Altitude, ground speed, climb rate and distance to home.
- **Flight actions** — Arm, take off, Hold, Return, Land and start a verified mission.
- **More pilot controls** — Flight modes, keyboard opt-in and voice settings.
- **Emergency stop** — Separate motor-cutoff action with a deliberate confirmation.
- **Map / video** — The map is the main workspace. Video is available on demand.

![01 / Fly — the main flight screen](01-fly.png)

Actual app interface · No aircraft connected · Feature labels are guide overlays.

## 02 / Plan — build and verify a mission

**Open: Plan**

- **Draft status & estimates** — Local / verified mission state, item count, distance and estimated duration.
- **Survey generator** — Create lawnmower survey lines from area size and lane spacing.
- **Import / export** — Read and save the supported QGroundControl .plan subset.
- **Upload & readback** — Send to the flight controller or read its mission; transfer requires a connection.
- **Mission items** — Select and inspect takeoff, waypoint and landing items.
- **Reorder & altitude** — Move / delete items and edit home-relative altitude.

![02 / Plan — build and verify a mission](02-plan.png)

Actual app interface · Illustrative local mission draft · No aircraft connected.

## 03 / Vehicle — flight-controller parameters

**Open: Vehicle**

- **Parameter search** — Filter the parameter list by name.
- **Download & recovery** — Request all parameters or fetch missing entries.
- **Backup / restore** — Save vehicle settings or preview differences before restoring.
- **Typed parameters** — Name, value and MAVLink type are shown together.
- **Readback status** — Edits stay pending until the controller confirms the value.

![03 / Vehicle — flight-controller parameters](03-vehicle.png)

Actual parameter screen · Illustrative parameter values only · No aircraft connected.

## 04 / Analyze — telemetry and flight events

**Open: Analyze**

- **Signal selection** — Toggle altitude, speed, climb, voltage and packet loss.
- **Telemetry plots** — Compare the selected signals over time.
- **Flight event timeline** — Review timestamps, command outcomes and mode events.
- **Export CSV** — Save the plotted data for offline analysis.
- **Historical CSV review** — Load a CSV as historical plots. This does not replay a live vehicle.

![04 / Analyze — telemetry and flight events](04-analyze.png)

Actual Analyze workspace · Generated sample curves and sample events · No aircraft connected.

## 05 / Settings — appearance, video and alerts

**Open: Settings**

- **Appearance** — Switch between the ivory / sage light theme and dark mode.
- **Video source** — Choose RTSP, UDP, HTTP, USB camera index, or an explicit test feed.
- **Battery chemistry** — Choose the battery cell count used for GCS voltage alerts.
- **Warning / critical limits** — Save voltage and percentage alert thresholds; these do not set PX4 failsafes.
- **Offline maps** — Load an MBTiles package or return to OpenStreetMap.

![05 / Settings — appearance, video and alerts](05-settings.png)

Actual app interface · No aircraft connected · Feature labels are guide overlays.

## 06 / Diagnostics — detailed system monitoring

**Open: Diagnostics**

- **Stream freshness** — Independent health and age for heartbeat, position, GNSS, attitude, power and speed.
- **Vehicle & session** — Firmware, armed duration and home information.
- **Live trend plots** — Altitude and ground-speed trends have a dedicated space.
- **MAVLink / ACK log** — Filter messages and inspect accepted, rejected or failed commands.
- **Second window** — Detach the same live diagnostics to another monitor.
- **Flight trail export** — Export the recorded flight trajectory as KML.

![06 / Diagnostics — detailed system monitoring](06-diagnostics.png)

Actual Diagnostics workspace · Example plot curves; stream status remains disconnected.

## 07 / Vehicle connection

**Open: Connection… or Connect vehicle**

- **Connection profile** — Choose a predefined SITL, UDP, TCP or serial profile.
- **MAVLink address** — Inspect or enter the transport address.
- **Connect / disconnect** — Open a transport and wait for the autopilot heartbeat.

![07 / Vehicle connection](07-connection.png)

Actual app interface · No aircraft connected · Feature labels are guide overlays.

## 08 / Additional pilot controls

**Open: Fly → More flight controls…**

- **Flight mode** — Select a mode and request it; PX4 validates its prerequisites.
- **Keyboard opt-in** — Enable guarded keyboard control; typing and focus changes inhibit motion.
- **Voice announcements** — Turn spoken status announcements on or off.

![08 / Additional pilot controls](08-pilot-controls.png)

Actual app interface · No aircraft connected · Feature labels are guide overlays.

## 09 / Preflight checklist

**Open: Preflight checklist in the header**

- **Battery configuration** — Select the expected pack cell count.
- **Evidence-based checks** — Link, GNSS, power, sensors, attitude, readiness and home are checked.
- **Go / no-go summary** — Missing evidence stays UNKNOWN; it never becomes a false pass.
- **Refresh status** — Re-evaluate the current telemetry evidence.

![09 / Preflight checklist](09-preflight.png)

Actual app interface · No aircraft connected · Feature labels are guide overlays.

## 10 / Survey grid generator

**Open: Plan → Survey grid**

- **Survey area** — Set the width and height of the mapping area.
- **Lane spacing** — Choose the separation between parallel flight lines.
- **Survey altitude** — Choose the home-relative altitude for generated points.
- **Estimate & generate** — Review the waypoint estimate, then generate the survey draft.

![10 / Survey grid generator](10-survey.png)

Actual app interface · No aircraft connected · Feature labels are guide overlays.

## 11 / Parameter restore preview

**Open: Vehicle → Load backup → select a file**

- **Difference table** — Compare the controller value with the backup value and parameter type.
- **Update / skip decisions** — Unchanged and unknown parameters are identified before writing.
- **Apply reviewed updates** — Send only supported updates after reviewing the differences.

![11 / Parameter restore preview](11-restore.png)

Actual restore dialog · Illustrative backup comparison · No parameter writes are performed.

## 12 / Diagnostics on a second display

**Open: Diagnostics → Open in second window**

- **Independent monitor** — Keep system health visible while Fly stays on the primary screen.
- **Same live plots** — Detaching moves the original widgets; it does not duplicate their histories.
- **ACK monitoring** — Inspect command messages without covering the flight map.

![12 / Diagnostics on a second display](12-second-window.png)

Actual detached window · Close the window to restore it to the Diagnostics tab.

## 13 / Fly with a video inset

**Open: Fly → Show video; choose a source in Settings**

- **Video inset** — Watch a configured feed while retaining the large map.
- **Stream state** — Disconnected, connecting, live, stale, failed and test states are explicit.
- **Swap map / video** — Promote video to the main view; the map becomes the inset.
- **Show / hide video** — Collapse the video view when it is not needed.

![13 / Fly with a video inset](13-video-inset.png)

Actual video layout · The colored bars are an explicitly labelled TEST PATTERN, not camera footage.

## 14 / Video as the primary view

**Open: video inset → Swap**

- **Primary video** — The video stream fills the monitoring workspace.
- **Map inset** — The map remains available in the smaller inset.
- **Return to map** — Swap again, or hide video to restore map-first operation.

![14 / Video as the primary view](14-video-primary.png)

Actual primary-video layout · Explicit TEST PATTERN feed · No camera or aircraft connected.

## 15 / Emergency motor-stop confirmation

**Open: Fly → Emergency motor stop… when the action is available**

- **Consequences stated** — The dialog explicitly describes immediate loss of motor power.
- **Deliberate confirmation** — Yes confirms the cutoff request; Cancel is the default.

![15 / Emergency motor-stop confirmation](15-emergency.png)

Actual confirmation dialog recreated for illustration · No aircraft connected; no command is sent.

## 16 / Historical flight-log review

**Open: Analyze → Load log replay → select a CSV**

- **Historical-data banner** — Makes clear that these are historical plots, separate from live flight.
- **Review plotted signals** — Inspect the imported time series with the same plot controls.
- **Exit log review** — Return from historical review to the normal Analyze workspace.

![16 / Historical flight-log review](16-historical-review.png)

Actual historical-review layout · Generated sample data · No live vehicle replay is claimed.

## 17 / Optional 3D attitude mode

**Open: Fly → Attitude → 3D**

- **2D / 3D selector** — Switch between the standard PFD and optional 3D aircraft attitude view.
- **3D renderer area** — This view requires WebGL. The capture environment may leave this viewport blank.

![17 / Optional 3D attitude mode](17-3d-attitude.png)

Actual 3D-mode layout · WebGL rendering is unavailable in this capture environment; no model image is fabricated.
